[Accesible SFC v1.0]

Members: Sangbuem Leonard Choo, Nikko Mizutani, Eunah Cho, Yukio Nozawa


Folders included:

1. Android - This folder contains only selected files from the Android Studio project.
		We've only included files that are significant and different from the Eclipse project.
	     
	activity_main.xml
		Takes care of the view. (Kind of like a HTML and CSS)

	MainActivity.java
		The main function (Kind of like a Javascript file)

	
	

2. Java - This folder contains an Eclipse executable file
	
	This can be executed in Eclipse and it will log the results in the console. 

